#!/bin/bash

# Si no se pone nigun proceso, dice el siguiente mensaje.
if [ -z "$1" ]; then
	echo "Ingrese el nombre del proceso a monitorear"
  exit 1
fi

# Aca verificamos que se este corriendo el proceso indicado anteriormente.
# Si no esta corriendo, envia un mail a root avisandole. 

proceso="$1"
echo "Buscando proceso $proceso"
if pgrep -x "$proceso" > /dev/null; then
  echo "El proceso $proceso está en ejecución."
else
  echo "El proceso $proceso no está en ejecución. Enviando correo a root."
  echo "El proceso $proceso no está en ejecución en $(date)." | mutt -s "Alerta: Proceso $proceso no está en ejecución" root
fi




