#!/bin/bash

# Definir array que asocie los días feriados.
# Los feriados fueron obtenidos de la siguiente página web: 
# http://servicios.infoleg.gob.ar/infolegInternet/anexos/170000-174999/174389/norma.htm
declare -A feriados
feriados=(
  ["01-01"]="Año Nuevo"
  ["24-03"]="Día Nacional de la Memoria por la Verdad y la Justicia"
  ["01-01"]="Año Nuevo"
  ["20-02"]="Carnaval"
  ["21-02"]="Carnaval"
  ["24-03"]="Día Nacional de la Memoria por la Verdad y la Justicia"
  ["02-04"]="Viernes Santo"
  ["01-05"]="Día del Trabajador"
  ["25-05"]="Día de la Revolución de Mayo"
  ["17-06"]="Día del Paso a la Inmortalidad del General Martín Miguel de Güemes"
  ["20-06"]="Día del Paso a la Inmortalidad del General Manuel Belgrano"
  ["09-07"]="Día de la Independencia"
  ["15-08"]="Día de la Asunción de la Virgen"
  ["10-10"]="Día del Respeto a la Diversidad Cultural"
  ["20-11"]="Día de la Soberanía Nacional"
  ["08-12"]="Día de la Inmaculada Concepción de María"
  ["25-12"]="Navidad"
)

# Función para validar la fecha
validarFecha() {
  local fecha=$1
  if ! [[ $fecha =~ ^[0-3][0-9]-[0-1][0-9]-[0-9]{4}$ ]]; then
    echo "Formato de fecha incorrecto. Asegúrese de usar DD-MM-AAAA."
    exit 1
  fi
}

# Función para verificar si es fin de semana
esFinDeSemana() {
  local fecha=$1
  local diaSemana

  # Se convierte el día de la semana a número para identificar los sábados al número 6 y domingos al número 7
  diaSemana=$(date -d "${fecha:6:4}-${fecha:3:2}-${fecha:0:2}" +%u)

  # Si coincide se puede identificar cuando cae en un fin de semana 
  if [[ $diaSemana -eq 6 || $diaSemana -eq 7 ]]; then
    echo "La fecha $fecha cae en fin de semana."
    exit 0
  fi
}

# Función para verificar si es feriado:
# Se toma la fecha larga en formao DDMMAAAA y se le anula el año creando la variable 
# Fecha_corta

# Con el if se asegura si la fecha_corta está dentro del array de feriados que definímos arriba
# en ese caso se confirma que sea un feriado.

esFeriado() {
  local fecha_larga=$1
  local fecha_corta="${fecha_larga:0:5}"
  if [[ ${feriados[$fecha_corta]+_} ]]; then
    echo "La fecha $fecha_larga es un feriado: ${feriados[$fecha_corta]}"
    exit 0
  else
    echo "La fecha $fecha no es un feriado."
  fi
}

# Verificar si se ha proporcionado un argumento
if [[ $# -ne 1 ]]; then
  echo "Uso: $0 DD-MM-AAAA"
  exit 1
fi

fecha="$1"
# Validar la fecha
validarFecha "$fecha"
# Verificar si es fin de semana
esFinDeSemana "$fecha"
# Verificar si es feriado
esFeriado "$fecha"
http://servicios.infoleg.gob.ar/infolegInternet/anexos/170000-174999/174389/norma.htm
